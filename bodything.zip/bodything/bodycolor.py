import time, ctypes
import asyncio, aiohttp
import random

cookie = open('cookie.txt' , 'r').readline().strip()
print (cookie)


success = False
sent_requests = 0


colors = [361,192,217,153,359,352,5,101,1007,1014,38,18,125,1030,133,106,105,1017,24,334,226,141,1021,28,37,310,317,119,1011,1012,1010,23,305,102,45,107,1018,1027,1019,1013,11,1024,104,1023,321,1015,1031,1006,1026,21,1004,1032,1016,330,9,1025,364,351,1008,29,1022,151,135,1020,1028,1009,1029,1003,26,199,194,1002,208,1,1001]



async def thread(): #sends the request to change body colors until it is successful
    global success, sent_requests
    async with aiohttp.ClientSession() as session:
        while success == False:
                async with session.post('https://avatar.roblox.com/v1/avatar/set-body-colors', cookies=cookies, json={"headColorId":random.choice(colors),"torsoColorId":random.choice(colors),"rightArmColorId":random.choice(colors),"leftArmColorId":random.choice(colors),"rightLegColorId":random.choice(colors),"leftLegColorId":random.choice(colors)}, headers=headers, timeout=5) as resp:
                    r = await resp.json()
                print(r)
                if 'Success' in r:
                    success = True
                sent_requests += 1
                print(sent_requests)
    





async def main(): #checks if the cookie entered is valid
    async with aiohttp.ClientSession() as session:
        async with session.get('https://www.roblox.com/mobileapi/userinfo', cookies=cookies, timeout=5) as resp:
            r = str(resp.url)
        if 'mobileapi/user' not in r:
            input('Invalid Cookie.')
            exit()


                #gets the X-CSRF-TOKEN
        async with session.post('https://auth.roblox.com/v2/login', cookies=cookies, timeout=5) as resp:
            r = resp.headers
        xcrsf = r['X-CSRF-TOKEN']



        
    start=time.time()
    await asyncio.sleep(3)
    headers['X-CSRF-TOKEN'] =  xcrsf





headers = {'X-CRSF-TOKEN': ''}
cookies = {'.ROBLOSECURITY': cookie}

asyncio.run(main())
asyncio.run(thread())

input('Finished.')
